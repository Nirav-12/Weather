import { useState } from "react";
import { View, Text, ImageBackground, Button } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

import Heading from "../components/Heading";
import GetText from "../components/GetText";
import NavButton from "../components/NavButton";

const SingUp = () => {
  const jasonvalue = JSON.stringify(userInfo);
  AsyncStorage.setItem("userData", jasonvalue);

  const Validation = () => {
    if (userInfo.password == userInfo.confirmPassword) {
      return false;
    } else {
      return true;
    }
  };

  const [userInfo, setUserInfo] = useState({
    name: "",
    password: "",
    confirmPassword: "",
    location: "",
  });
  return (
    <ImageBackground
      source={require("../Images/Weather.jpg")}
      style={{ flex: 1 }}
    >
      <View style={{ margin: 20 }} />
      <Heading name="Sing Up " />
      <View style={{ margin: 40 }} />
      <GetText
        placeholder="Your Name"
        onChangeText={(user) =>
          setUserInfo((prevState) => ({ ...prevState, name: user }))
        }
      />
      <View style={{ margin: 10 }} />
      <GetText
        placeholder="Password"
        onChangeText={(pass) =>
          setUserInfo((prevState) => ({ ...prevState, password: pass }))
        }
      />
      <View style={{ margin: 10 }} />
      <GetText
        placeholder="conform Password"
        onChangeText={(value) =>
          setUserInfo((state) => ({ ...state, confirmPassword: value }))
        }
      />
      <View style={{ margin: 10 }} />
      <GetText
        placeholder="Location"
        onChangeText={(value) =>
          setUserInfo((prevState) => ({ ...prevState, location: value }))
        }
      />
      <View style={{ margin: 60 }} />
      <NavButton
        title="Sing Up"
        disabled={Validation()}
        onPress={() => {
          alert("Successfully SingUp");
        }}
      />
      <Button title="GET STRING" onPress={() => console.log(jasonvalue)} />
    </ImageBackground>
  );
};
export default SingUp;
