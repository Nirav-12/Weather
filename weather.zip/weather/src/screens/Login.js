import { View, ImageBackground, Button } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

import GetText from "../components/GetText";
import Heading from "../components/Heading";
import ClickTouch from "../components/ClickTouch";
import WeatherReport from "./WeatherReport";
import SingUp from "./SingUp";
import ForgotPass from "./ForgotPass";
import NavButton from "../components/NavButton";

const Login = ({ navigation }) => {
  return (
    <View style={{ flex: 1 }}>
      <ImageBackground
        source={require("../Images/Weather.jpg")}
        style={{ flex: 1 }}
      >
        <View style={{ margin: 20 }} />
        <Heading name="Login " />
        <View style={{ margin: 40 }} />
        <GetText placeholder="User Name" />
        <View style={{ margin: 10 }} />
        <GetText placeholder="PassWord" />

        <View style={{ margin: 10 }} />
        <View style={{ flexDirection: "row", justifyContent: "center" }}>
          <ClickTouch
            text="SingUp"
            onPress={() => navigation.navigate(SingUp)}
          />
          <View style={{ margin: 60 }} />
          <ClickTouch
            text="Forgot PassWord ?"
            onPress={() => navigation.navigate(ForgotPass)}
          />
        </View>
        <NavButton
          title="Login"
          onPress={() => navigation.navigate(WeatherReport)}
        />
      </ImageBackground>
    </View>
  );
};
export default Login;
