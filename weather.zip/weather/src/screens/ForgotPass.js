import { ImageBackground, View } from "react-native";

import GetText from "../components/GetText";
import NavButton from "../components/NavButton";
import Heading from "../components/Heading";

const ForgotPass = () => {
  return (
    <ImageBackground
      source={require("../Images/Weather.jpg")}
      style={{ flex: 1 }}
    >
      <Heading name="Forgot Password  " />
      <View style={{ margin: 60 }} />
      <GetText placeholder="User Name " />

      <View style={{ margin: 60 }} />

      <NavButton
        title="Get Password"
        onPress={() => console.log("Your PassWord is")}
      />
    </ImageBackground>
  );
};
export default ForgotPass;
