import { View, Text, ImageBackground } from "react-native";

const WeatherReport = () => {
  return (
    <ImageBackground
      source={require("../Images/Weather.jpg")}
      style={{ flex: 1 }}
    ></ImageBackground>
  );
};
export default WeatherReport;
