import { TouchableOpacity, View, Text } from "react-native";

const NavButton = (props) => {
  return (
    <View>
      <TouchableOpacity
        {...props}
        style={{
          width: "30%",
          height: 30,
          alignItems: "center",

          backgroundColor: "red",
          alignSelf: "center",
        }}
      >
        <Text style={{ alignSelf: "center" }}>{props.title}</Text>
      </TouchableOpacity>
    </View>
  );
};
export default NavButton;
