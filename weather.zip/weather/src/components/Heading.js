import { View, Text, StyleSheet } from "react-native";

const Heading = (props) => {
  return (
    <View style={styles.view}>
      <Text style={styles.text}>{props.name}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  view: { alignItems: "center" },
  text: { fontSize: 35 },
});
export default Heading;
