import { View, TextInput, StyleSheet } from "react-native";

const GetText = (props) => {
  return (
    <View style={styles.view}>
      <TextInput
        placeholder={props.placeholder}
        style={styles.textInpute}
        {...props}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  view: { alignItems: "center" },
  textInpute: {
    borderWidth: 1,
    height: 50,
    width: "70%",
    borderRadius: 15,
    backgroundColor: "white",
  },
});

export default GetText;
