import { View, Text, TouchableOpacity } from "react-native";

const ClickTouch = (props) => {
  return (
    <TouchableOpacity {...props}>
      <Text> {props.text} </Text>
    </TouchableOpacity>
  );
};

export default ClickTouch;
